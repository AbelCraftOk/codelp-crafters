import os
import sqlite3

def ensure_database():
    db_path = "C:\\Program Files\\Gestor de Contraseñas\\base.db"
    if not os.path.exists(db_path):
        os.system("python C:\\Program Files\\Gestor de Contraseñas\\base.py")
    return db_path

def execute_query(query, params=()):
    db_path = ensure_database()
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(query, params)
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False

def fetch_all(query):
    db_path = ensure_database()
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(query)
        result = cursor.fetchall()
        conn.close()
        return result
    except Exception as e:
        print(f"Error: {e}")
        return []

def home():
    os.system("cls")
    print("Estas en la pestaña: Inicio")
    print("---------------------------")
    print("¿Que deseas hacer?")
    print("1- Agregar una nueva contraseña")
    print("2- Borrar una contraseña")
    print("3- Ver las contraseñas agregadas")

    choice = input("Selecciona una opción: ")
    if choice == "1":
        add()
    elif choice == "2":
        delate()
    elif choice == "3":
        list_passwords()
    else:
        print("Opción inválida. Volviendo al inicio...")
        home()

def add():
    os.system("cls")
    print("Estas en la pestaña: Agregar una nueva contraseña")
    print("---------------------------")

    usuario = input("El usuario es: ")
    clave = input("La contraseña es: ")
    fuente = input("El sitio web / Aplicacion es: ")

    query = """
    INSERT INTO claves (usuario, clave, fuente) VALUES (?, ?, ?)
    """

    if execute_query(query, (usuario, clave, fuente)):
        os.system("C:\\Program Files\\Gestor de Contraseñas\\add+.vbs")
    else:
        os.system("C:\\Program Files\\Gestor de Contraseñas\\add-.vbs")

    home()

def delate():
    os.system("cls")
    print("Estas en la pestaña: Borrar una contraseña")
    print("---------------------------")

    fuente = input("El sitio web / aplicacion es: ")

    query = """
    DELETE FROM claves WHERE fuente = ?
    """

    if execute_query(query, (fuente,)):
        os.system("C:\\Program Files\\Gestor de Contraseñas\\delate+.vbs")
    else:
        os.system("C:\\Program Files\\Gestor de Contraseñas\\delate-.vbs")

    home()

def list_passwords():
    os.system("cls")
    print("Estas en la pestaña: Listado de contraseñas")
    print("---------------------------")

    query = "SELECT usuario, clave, fuente FROM claves"
    passwords = fetch_all(query)

    if passwords:
        for idx, (usuario, clave, fuente) in enumerate(passwords, start=1):
            print(f"{idx}. Usuario: {usuario} | Contraseña: {clave} | Fuente: {fuente}")
    else:
        print("No hay contraseñas guardadas.")

    input("Presiona Enter para volver al inicio...")
    home()

def main():
    home()

if __name__ == "__main__":
    main()
