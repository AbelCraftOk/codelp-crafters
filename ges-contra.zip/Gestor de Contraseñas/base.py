import sqlite3

def crear_base_de_datos():
    # Conectar (o crear) la base de datos
    conexion = sqlite3.connect("base.db")
    
    # Crear un cursor para ejecutar comandos SQL
    cursor = conexion.cursor()
    
    # Crear la tabla "claves" si no existe
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS "claves" (
        "usuario" INTEGER,
        "clave" INTEGER,
        "fuente" INTEGER
    );
    ''')
    
    # Guardar cambios y cerrar la conexión
    conexion.commit()
    conexion.close()
    print("Base de datos y tabla creadas exitosamente.")

# Ejecutar la función para crear la base de datos y la tabla
crear_base_de_datos()
